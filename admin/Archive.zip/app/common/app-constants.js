//(function(){
//    //angular.module('tmx-app').
//    //    constant('APP_CONSTANTS', {
//    //        "BASE_URL": "http://172.17.40.106:85/api/v1/"
//    //        //"BASE_URL": //" http://172.20.1.196:9097/api/"
//    //    });
//        //constant('PROVISIONING_CONSTANTS', {
//        //    //"AUTHSERVER_106" : {
//	     //    //   "BASE_URL": "http://172.17.40.106:96",
//		 //   //    "LOGIN_URL":'/token',
//		 //   //    "TOKEN_NAME":'access_token'
//		 //   //}
//        //});
//})();

(function(){
    angular.module('yapp').
    constant('SeatEatsConstants', {

      "AppUrl":"http://localhost:8000/",
      "AppUrlApi":"http://localhost:8000/api/",
    });
})();
